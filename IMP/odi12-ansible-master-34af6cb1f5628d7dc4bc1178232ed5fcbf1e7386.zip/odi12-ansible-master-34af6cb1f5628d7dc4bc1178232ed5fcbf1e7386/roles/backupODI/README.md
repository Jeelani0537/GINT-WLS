backupODI
=========

This role will create backups of ORACLE HOME and all the domains linked to it on the targeted servers. 
The backup will be in .tar.gz format with a timestamp in YYMMDDHHMMSS format, for example:

/opt/oracle/domains12.2/PTOWD3642.bkp200401115012.tar.gz

The backups will be located under the respective parent directories.

Requirements
------------

No requirements.

Role Variables
--------------

The role requires the following variables set:
* ORACLE_HOME (FQP to binary installation)

If not provided, they default to OI domain setup standards:

ORACLE_HOME: /opt/oracle/FMW12.2

Dependencies
------------

The role uses the custom filter "get_domains" to get all the domain directories registered for a givem binary installation.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - backupODI

License
-------

For internal use only.

Author Information
------------------

kai.fricke@ingka.com