shutdownODI
===========

This role detects ALL running WL server and node manager instances on the targeted host(s) and shuts them down. Currently it expects that the servers are started with node manager leveraging the scripts provided by OI Domain creation framework.

Requirements
------------

Linux ps command has to be availabe on target hosts.

Role Variables
--------------

No variables are used.

Dependencies
------------

The role uses  the custom filter "shutdown_wls_command" to construct the server shoudown command from the server startup parameters.

Example Playbook
----------------

    - hosts: servers
      roles:
         - shutdownODI

License
-------

For internal use only

Author Information
------------------

kai.fricke@ingka.com